#include <linux/module.h>
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0x7ca88ad8, "module_layout" },
	{ 0x2d3385d3, "system_wq" },
	{ 0x46a9479b, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0xc8ae5007, "put_devmap_managed_page" },
	{ 0x53b954a2, "up_read" },
	{ 0x43e0cfb0, "pci_release_region" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x10c44c4e, "dma_set_mask" },
	{ 0x3e81cefd, "pci_disable_device" },
	{ 0x3eea024a, "remove_proc_entry" },
	{ 0x999e8297, "vfree" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x668b19a1, "down_read" },
	{ 0x6b10bee1, "_copy_to_user" },
	{ 0xd088d9cd, "PDE_DATA" },
	{ 0x25974000, "wait_for_completion" },
	{ 0x3812050a, "_raw_spin_unlock_irqrestore" },
	{ 0xfeba7354, "current_task" },
	{ 0x20463df4, "wait_for_completion_killable" },
	{ 0xc5850110, "printk" },
	{ 0xe1537255, "__list_del_entry_valid" },
	{ 0x4c9d28b0, "phys_base" },
	{ 0x531b604e, "__virt_addr_valid" },
	{ 0x2e3bcce2, "wait_for_completion_interruptible" },
	{ 0x2fcf0ae3, "dma_direct_map_page" },
	{ 0x92d5838e, "request_threaded_irq" },
	{ 0xef162092, "pci_enable_msi" },
	{ 0x68f31cbd, "__list_add_valid" },
	{ 0x42160169, "flush_workqueue" },
	{ 0xe523ad75, "synchronize_irq" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xb2dd7d37, "module_put" },
	{ 0xa961be37, "dma_direct_unmap_page" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0x83cde979, "get_user_pages" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xfd9ce0a0, "pci_unregister_driver" },
	{ 0xc27f683d, "kmem_cache_alloc_trace" },
	{ 0x51760917, "_raw_spin_lock_irqsave" },
	{ 0xd3684ad2, "proc_create_data" },
	{ 0x37a0cba, "kfree" },
	{ 0x69acdf38, "memcpy" },
	{ 0x96fee2ac, "pci_disable_msi" },
	{ 0x8a32c8cf, "__pci_register_driver" },
	{ 0x608741b5, "__init_swait_queue_head" },
	{ 0xc5b6f236, "queue_work_on" },
	{ 0xa6257a2f, "complete" },
	{ 0x656e4a6e, "snprintf" },
	{ 0xfeb35f0d, "vmalloc_to_page" },
	{ 0x2fee7093, "pci_enable_device" },
	{ 0x13c49cc2, "_copy_from_user" },
	{ 0x52e18422, "pci_request_region" },
	{ 0xa51111ba, "dma_ops" },
	{ 0x88db9f48, "__check_object_size" },
	{ 0xc389fa4f, "__put_page" },
	{ 0xd2bc0a65, "try_module_get" },
	{ 0xc31db0ce, "is_vmalloc_addr" },
	{ 0xc1514a3b, "free_irq" },
	{ 0x587f22d7, "devmap_managed_key" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("pci:v00001AB8d00004000sv*sd*bc*sc*i*");

MODULE_INFO(srcversion, "FA721B3FEEA927A8471BAFF");
