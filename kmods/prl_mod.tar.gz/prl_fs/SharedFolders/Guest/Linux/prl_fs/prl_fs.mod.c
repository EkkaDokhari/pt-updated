#include <linux/module.h>
#include <linux/build-salt.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(.gnu.linkonce.this_module) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section(__versions) = {
	{ 0x7ca88ad8, "module_layout" },
	{ 0x46a9479b, "kmalloc_caches" },
	{ 0xeb233a45, "__kmalloc" },
	{ 0xa98d2c6e, "make_bad_inode" },
	{ 0x81e190bc, "generic_file_llseek" },
	{ 0x79ef6fce, "__mark_inode_dirty" },
	{ 0x349cba85, "strchr" },
	{ 0x754d539c, "strlen" },
	{ 0x40da874a, "d_set_d_op" },
	{ 0xd04d489, "kill_anon_super" },
	{ 0x9822e606, "seq_open" },
	{ 0xb8b043f2, "kfree_link" },
	{ 0xf4a9707, "seq_puts" },
	{ 0x3c80558, "seq_printf" },
	{ 0x3eea024a, "remove_proc_entry" },
	{ 0xa510c36f, "pci_dev_get" },
	{ 0x85df9b6c, "strsep" },
	{ 0x5a3e4eb9, "d_add" },
	{ 0x27d1ab67, "generic_read_dir" },
	{ 0xa18de3c7, "mount_nodev" },
	{ 0x97651e6c, "vmemmap_base" },
	{ 0x3c3ff9fd, "sprintf" },
	{ 0x5a64fc2b, "seq_read" },
	{ 0xdaa47f9e, "pv_ops" },
	{ 0x15ba50a6, "jiffies" },
	{ 0x28353a27, "truncate_setsize" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x86f9f1f9, "make_kgid" },
	{ 0xfb578fc5, "memset" },
	{ 0xdb6dc6d7, "pci_get_subsys" },
	{ 0xa195cc0a, "from_kuid" },
	{ 0x9caa4324, "proc_mkdir" },
	{ 0xfeba7354, "current_task" },
	{ 0xc5850110, "printk" },
	{ 0xa1c76e0a, "_cond_resched" },
	{ 0x9166fada, "strncpy" },
	{ 0x92fda6c0, "from_kgid" },
	{ 0x1533c759, "call_tg_sync" },
	{ 0x5c200148, "setattr_copy" },
	{ 0x62912184, "dentry_path_raw" },
	{ 0x2c541e7b, "radix_tree_next_chunk" },
	{ 0x70ff26d7, "unlock_page" },
	{ 0xce807a25, "up_write" },
	{ 0x57bc19d2, "down_write" },
	{ 0x7cd8d75e, "page_offset_base" },
	{ 0xc6cbbc89, "capable" },
	{ 0x9f984513, "strrchr" },
	{ 0xa916b694, "strnlen" },
	{ 0x79dd6292, "generic_file_mmap" },
	{ 0x42bd4122, "truncate_inode_pages_final" },
	{ 0xee5729ce, "make_kuid" },
	{ 0xdecd0b29, "__stack_chk_fail" },
	{ 0xf54ca842, "unlock_new_inode" },
	{ 0xd990de27, "inode_newsize_ok" },
	{ 0x2ea2c95c, "__x86_indirect_thunk_rax" },
	{ 0xbdfb6dbb, "__fentry__" },
	{ 0xcbd4898c, "fortify_panic" },
	{ 0xc27f683d, "kmem_cache_alloc_trace" },
	{ 0xdbf17652, "_raw_spin_lock" },
	{ 0x82969103, "register_filesystem" },
	{ 0xe953b21f, "get_next_ino" },
	{ 0x3f4fca4d, "seq_lseek" },
	{ 0xe0021a82, "iput" },
	{ 0x37a0cba, "kfree" },
	{ 0x21559240, "iunique" },
	{ 0x84c8b2b6, "generic_permission" },
	{ 0x69acdf38, "memcpy" },
	{ 0x2adb908b, "current_time" },
	{ 0xd65e4c0a, "d_make_root" },
	{ 0xd5748537, "unregister_filesystem" },
	{ 0xf5aaa50c, "pci_dev_put" },
	{ 0x6069e1a6, "seq_release" },
	{ 0xb007c18a, "new_inode" },
	{ 0x5f214e36, "proc_create" },
	{ 0x39786751, "noop_fsync" },
	{ 0xeeabf456, "clear_inode" },
	{ 0x389641a, "d_instantiate" },
	{ 0x19bdb245, "iget_locked" },
	{ 0xd955ad77, "generic_fillattr" },
	{ 0xfe9cfc9c, "filemap_fdatawrite" },
	{ 0xd71b6280, "super_setup_bdi_name" },
};

MODULE_INFO(depends, "prl_tg");

